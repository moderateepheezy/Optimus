
Simple app for tracking usage and managing of installed applications.

Min API level: 14

