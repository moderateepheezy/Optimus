package ru.max64.myappstime.util;

public class Prefs {

    public static final String INCLUDE_SYSTEM_APPS = "include system apps";
    public static final String SORT_INSTALLED = "sorting of installed apps list";
    public static final String STATS_PERIOD = "stats period";
    public static final String STATS_PERMISSION_GRANTED = "stats permission granted";

    private Prefs() {}

}
